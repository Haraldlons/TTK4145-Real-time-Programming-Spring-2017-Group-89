package main

import (
	. "./backup"
	. "./cost"
	"./driver"
	. "./log"
	"./network"
	. "./order"
	. "./types"
	"./watchdog"

	"encoding/json"
	"sort"
	"sync"
	"time"
)

var wg sync.WaitGroup

const CHECK_IF_THE_MOTOR_IS_ARRIVING_AT_SOME_FLOOR_AFTER_TRYING_TO_CYCLE_THE_MOTOR_DIRCETION_OR_REINITIALIZE_INTERVAL = 5 * time.Second

func main() {
	//testBackup()

	GenId()
	watchdog.Initiate()
	Free <- true

	Log.Info("Running main")

	// Receivers
	go handleMessages()
	go handleExternalOrdersFromDriver()
	go handleDeadPeers()

	go executeOrders()

	go RestoreOrders()

	go network.Listen()
	driver.ElevatorInit()

	Log.Notice("Main initiated")

	select {
	// run
	}
}

func handleDeadPeers() {
	for {
		select {
		case peer := <-network.DeadPeers:
			_ = peer
			orders := FindOrders(peer)
			// TODO check if there is a safer aglorithm for choosing "master"
			sort.Strings(network.ConnectedPeers)
			for _, order := range orders {
				order.Handler = ""
				SaveBackup(order) //updates
				if network.ConnectedPeers[0] == Me {
					network.Broadcast(order)
				}
			}
		}
	}
}

func handleMessages() {
	for {
		select {
		case msg := <-network.Messages:
			switch msg.ContentType {
			case "types.Order":
				var order Order
				j, _ := json.Marshal(msg.Content)
				json.Unmarshal(j, &order)
				if order.Done {
					Log.Notice("Notified that external order is executed. Floor:", order.Floor)
					DeleteBackup(order)
					driver.ClearExternalOrder(order)
				} else {
					switch order.Handler {
					case "":
						SaveBackup(order)
						Log.Notice("Unhandled order received, replying with availibility")
						go network.Broadcast(GetAvail())
						driver.SetExternalOrder(order)
					case Me:
						Log.Notice("Received order assigned to me")
						QueueOrder(order)
					}
				}
			case "cost.Availibility":
				var avail Availibility
				j, _ := json.Marshal(msg.Content)
				json.Unmarshal(j, &avail)
				Log.Notice("Received availibility from:", msg.Sender, avail.TimeToIdle)
				Availibilities[msg.Sender] = avail
			default:
				Log.Error("Got unhandled type", msg.ContentType)
			}
		}
	}
}

func handleExternalOrdersFromDriver() {
	for {
		select {
		case order := <-ExternalOrders:
			go func() {
				Log.Notice("Got external button press")
				UpdateAvail()
				received := network.Broadcast(order) // implies request of availibility
				time.Sleep(time.Second)
				if received { // or after timeout
					order.Handler = GetBest(order.Floor)
					Log.Notice("Handler is assigned to", order.Handler)
				}
				if order.Handler != "" && order.Handler == Me {
					QueueOrder(order)
					Log.Notice("I were the best")
				}
				SaveBackup(order)
				Log.Info("Notififying everyone about the update", order.Handler)
				network.Broadcast(order)
				//TODO verify order.Handler received
			}()
		}
	}
}

/*
	Acts in first in first out

	Internal orders from driver and network order from master goes directly in queue
	External orders sent to master

	Orders executed according to queue
*/
func executeOrders() {
	var prev Order
	for {
		if State.Responding {
			select {
			case <-OrderAvailible:
				order := Read()
				var done bool
				if order.Floor == prev.Floor && order.Type == prev.Type {
					Log.Warning("The same order was just served.")
					done = true
				} else {
					Log.Notice("Picking next order:", order.Floor)
					done = driver.GoTo(order.Floor)
				}
				if done {
					order = Pop()
					Log.Notice("Order done")
					if order.Type != INTERNAL {
						Log.Notice("Notifying others that the order is done")
						order.Done = true
						driver.ClearExternalOrder(order)
						network.Broadcast(order)
					}
					DeleteBackup(order)
				} else {
					if order.Type == INTERNAL {
						QueueOrder(order)
					} else {
						//ExternalOrders <- order
					}
				}
			}
		} else {
			time.Sleep(CHECK_IF_THE_MOTOR_IS_ARRIVING_AT_SOME_FLOOR_AFTER_TRYING_TO_CYCLE_THE_MOTOR_DIRCETION_OR_REINITIALIZE_INTERVAL)
		}
	}
}

func testBackup() {
	//TODO:Maybe make an utilities file where stuff like this is saved

	//Make own order
	order := Order{Id: "asdf1", Floor: 3, Handler: "gunnar", Done: false}
	SaveBackup(order)

	//Make order for elevator 007
	order = Order{Id: "asdf2", Floor: 1, Handler: "", Done: true}
	SaveBackup(order)

	//Make order for elevator 666
	order = Order{Id: "asdf3", Floor: 1, Handler: "bob", Done: true}
	SaveBackup(order)

	//Make order for elevator 666
	order = Order{Id: "asdf4", Floor: 1, Handler: "bob", Done: true}
	SaveBackup(order)

	//Make order for elevator 666
	order = Order{Id: "asdf5", Floor: 1, Handler: "bob", Done: true}
	SaveBackup(order)

	//Remove order 666 of elevator 666
	DeleteBackup(order)

	//Get own backup order with order id = 111
	orders := FindOrders("bob")
	Log.Warning("Bob's orders are", orders)
}

func handleForgottenOrders() {
	for {
		select {
		//case <- time.After()
		}
	}
	//TODO only if there is time. for some interval, check if some orders is not served, that should be served
}
