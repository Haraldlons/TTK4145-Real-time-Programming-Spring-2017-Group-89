package backup

import (
	. "../log"
	. "../types"

	"bytes"
	"encoding/json"
	"io/ioutil"
	"os"
	"path"
	"path/filepath"
	"runtime"
	"strings"
)

const ORDER_DIR = "backup/orders/"

func GetPath() string {
	_, filename, _, ok := runtime.Caller(0)
	if !ok {
		panic("No caller information")
	}
	return path.Dir(filename)
}

//SaveBackup takes an order as an input and creates a backup
func SaveBackup(order Order) {
	filename := ORDER_DIR + order.Id + ".json"
	w, err := os.Create(filename)
	Handle(err)

	//Make json file
	b, _ := json.Marshal(order)
	Log.Debug("Backed up", order.Id)
	w.Write(b)
	Handle(err)
	w.Close()
}

//DeleteBackup finds the requested backup and deletes it
func DeleteBackup(order Order) {
	err := os.Remove(ORDER_DIR + order.Id + ".json")

	Handle(err)
	Log.Debug("Deleted order", order.Id)
}

//FindOrders will get all the backups for the requested elevator
func FindOrders(handler string) Orders {
	var orders []Order
	if _, err := os.Stat(ORDER_DIR); os.IsNotExist(err) {
		os.Mkdir(ORDER_DIR, os.FileMode(0775))
	}

	//Getting the directory of the backup files
	var buffer bytes.Buffer
	buffer.WriteString(GetPath())
	buffer.WriteString("/orders")
	searchDir := buffer.String()

	files := []string{}
	err := filepath.Walk(searchDir, func(path string, f os.FileInfo, err error) error {
		files = append(files, path)
		return nil
	})
	Handle(err)

	//Finding the backup files
	for _, file := range files {

		if len(file) > len(searchDir)+6 {
			path := file[len(searchDir)+1:]
			order := readBackup(path)
			parts := strings.Split(handler, "-")
			h := parts[0] + "-" + parts[1]
			if strings.HasPrefix(order.Handler, h) {
				orders = append(orders, order)
			}
		}
	}
	return orders
}

func readBackup(path string) Order {
	var b []byte
	var err error

	if path != "" {
		filename := ORDER_DIR + path
		b, err = ioutil.ReadFile(filename)
	}
	Handle(err)

	var m Order
	err = json.Unmarshal(b, &m)
	Handle(err)

	return m
}
