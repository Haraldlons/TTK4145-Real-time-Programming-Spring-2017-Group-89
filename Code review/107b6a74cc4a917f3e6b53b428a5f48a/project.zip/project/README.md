# Project

## 3rd party packages

- github.com/op/go-logging
- github.com/stretchr/testify


## Design

### Modules and interfaces
- [IO](#io-module)
- [Driver](#driver-module)
- [Network](#network-module)
- [ElevatorController](#elevatorcontroller-module)
- [ExternalOrders](#externalorders-module)

#### IO module

- Commuicates directly with the hardware
- Abstracts bit-operations to human readable operations (eg. light door lamp)


#### Driver module 

Logic for hardware operations.

Eg. gets "Send elevator to floor 2!" from ElevatorController and calls neccessary operations from IO module "Get floor number" -> "Door open lamp off" -> "Motor direction down" etc.


#### Network module

Communicates with other elevators.
- Get their status (movment, floor and role [master,slave])
- Order them to carry out orders
- Monitor the connections to the other elevators (that they respond, eg. tell ElevatorController if the master died)


#### ElevatorController module

Act on 
- messages from master (eg. "go to floor X")
- missing message (dead connection)
- internal orders

#### ExternalOrders module
Triggered at external button press

##### Slaves
Notify master of external button press.

##### Master
Create external order
- Call NetworkModule to get the state of all elevators.
- Algorithm for choosing elevator that should carry out the order. 
- If the choosen elevator is itself, call Elevator Controller, else tell NetworkModule what elevator that was choosen for the order.
- Light button external button press on all elevators.
- Delete order and switch light on when order is done.

### Error handling

#### Power failure and software crash
Write orders to a text file 
- One line for necessary details, delete line when order is served.
- When the system boots up again, it checks the file for unserved orders.

An external order is saved locally. When the master is notified, the order is saved on the master and deleted on the the elevator that got it. When the master has ordered an elevator it is saved on that elevator and deleted on the master.

For internal orders, it is only saved at the local elevator.

#### Network disconnect
- If a elevator is disconnected from the system, it will set its own role to master with no slaves. 
- If the elevator that lost connection was master, the connected elevators must choose a new master amongst them.
- When the lost elevator connects again it will get status as slave in the existing cluster.

To achieve this:
- Ping alive requests
 - The slaves must ping the master continously to detect if it goes down
 - When a elevator gets disconnected, it must continously try to reconnect to the other elevators, and try to be enslaved by the master

### Cost function

Waiting time. Ie. the closest idle elevator. Or elevator in the correct direction.
