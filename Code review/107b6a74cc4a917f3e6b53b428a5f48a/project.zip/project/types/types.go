package types

import (
	. "../log"

	"flag"
	"fmt"
	"net"
	"os"
	"strings"
	"time"
)

type Order struct {
	Id       string
	Type     OrderType
	Floor    int
	Handler  string
	Done     bool
	Recorded time.Time
}

type Orders []Order

type OrderType uint8
type Direction int

type HardwareState struct {
	Floor      int
	Dir        Direction
	DoorOpen   bool
	Responding bool
}


var State HardwareState

const (
	GO_UP OrderType = iota
	GO_DOWN
	INTERNAL
)


const (
	DOWN Direction = -1 + iota
	STOP
	UP
)

var Me string
const GROUP_SECRET = "GROUP"

// The following three implements the sort interface for Order
func (slice Orders) Len() int {
	return len(slice)
}

func (slice Orders) Less(i, j int) bool {
	if slice[i].Recorded.Before(slice[j].Recorded) {
		return true
	} else {
		return false
	}
}

func (slice Orders) Swap(i, j int) {
	slice[i], slice[j] = slice[j], slice[i]
}

func GenId() {
	var id string
	flag.StringVar(&id, "id", "", "id of this peer")
	flag.Parse()

	if id == "" {
		conn, err := net.DialTCP("tcp4", nil, &net.TCPAddr{IP: []byte{8, 8, 8, 8}, Port: 53})
		Handle(err)
		defer conn.Close()
		ip := strings.Split(conn.LocalAddr().String(), ":")[0]
		parts := strings.Split(ip, ".")
		id = parts[2] + "." + parts[3]
	}
	Me = fmt.Sprintf("%s-%s-%d", GROUP_SECRET, id, os.Getpid())
}

func Handle(err error) {
	if err != nil {
		Log.Error("Error:", err.Error())
	}
}
