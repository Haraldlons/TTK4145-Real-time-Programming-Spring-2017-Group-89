package watchdog

import (
	. "../log"
	. "../types"

	"os"
	"os/exec"
	"runtime"
	"time"
	"net"
	"strings"
)

const(
	 BACKUP = "localhost:31536"
	 UDP_TYPE = "udp"
)

// Runs the main program
func RunMain() {
	 runShellCmd("go run main.go -id=" + strings.Split(Me, "-")[1])
}

func runShellCmd(cmd string) {
	pwd, _ := os.Getwd()

	var application, flag, command string
	switch runtime.GOOS {
	case "linux":
		out, _ := exec.Command("gnome-terminal", "-x", "sh", "-c", cmd + "; bash").Output()
		Log.Info("Command responded:", string(out))
	case "darwin":
		Log.Debug("Run on osx")
		application = "/usr/bin/osascript"
		flag = "-e"
		command = "tell app \"Terminal\" to do script \"cd " + pwd + "; " + cmd + "\""
		out, _ := exec.Command(application, flag, command).Output()
		Log.Info("Command responded:", string(out))
	case "windows":
		Log.Error("Network not supported on Windows")
		Log.Error("Watchdog not supported on Windows")
		return
	default:
		Log.Error("Unhandled OS:", runtime.GOOS)
		return
	}
}

// Kills a process
func Kill(pid string) {
	runShellCmd("kill " + pid)
}

// Initiates the watchdog, which will check for alive masters
// If there is none, it will spawn a watchdog,
// and transform to master itself
func Initiate() {
	Log.Info("Watchdog initiated")

	backupAddr, err := net.ResolveUDPAddr(UDP_TYPE, BACKUP)
	Handle(err)
	conn, err := net.ListenUDP(UDP_TYPE, backupAddr)
	Handle(err)
	masterAlive := true
	masterIsBroadcasting := false

  	for (masterAlive) {
    	conn.SetReadDeadline(time.Now().Add(time.Second))
		message := make([]byte, 1024)
		length, _, err := conn.ReadFromUDP(message)
		_ = string(message[0:length])

		if !masterIsBroadcasting {
			Log.Info("Master is broadcasting...")
			masterIsBroadcasting = true
		}
		if err != nil {
			Log.Debug("Error:", err.Error())
  			masterAlive = false
        	break
		}
	}
	conn.Close()
	Log.Warning("Master is dead, I am taking over")
	go broadcastAlive()
	go RunMain()
}

func broadcastAlive(){
	backupAddr, err := net.ResolveUDPAddr(UDP_TYPE, BACKUP)
	if err != nil {
		Log.Error("Couldn't resolve udp")
	}

	mconn,err := net.DialUDP(UDP_TYPE, nil, backupAddr)
	if err != nil {
		Log.Error("Couldn't dial udp")
	}
	defer mconn.Close()

	for {
		_, err = mconn.Write([]byte("I (" + Me + ") am alive"))
		if err != nil {
			Log.Critical("Watchdog did not reply!")
		}
		time.Sleep(time.Second/4)
	}
}
