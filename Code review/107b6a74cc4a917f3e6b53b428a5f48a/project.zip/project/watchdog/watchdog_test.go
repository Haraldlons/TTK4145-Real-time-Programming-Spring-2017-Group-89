package watchdog

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestRun(t *testing.T) {
	RunTest("echo I am tierd; sleep 5")
	assert.True(t, true, "Msg")
}
