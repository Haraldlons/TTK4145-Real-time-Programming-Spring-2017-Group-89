package order

import (
	"testing"
	"time"
	. "./../log"
	"github.com/stretchr/testify/assert"
)

//"github.com/stretchr/testify/assert"

func TestQueueOrder(t *testing.T) {
	var checkChannel Order

	go func() {
		for {
			select {
			case msg := <-OrderQueue:
				checkChannel = msg
			}
		}
	}()

	theOrder := Order{Id: "1", External: true, Floor: 3, Handler: "something", Done: false}

	QueueOrder(theOrder)
	time.Sleep(1 * time.Second)

	checkQueue := OrderQueueList.Front().Value.(Order)
	RemoveFromQueue()

	assert.Equal(t, checkQueue, checkChannel, "Sent struct should be same as received")

}
func TestRemoveOrderFromQueue(t *testing.T) {
	//Empty both lists

	enableRemove := true
	var checkChannel Order
	var checkQueue    Order
	go func() { for {
		if enableRemove{
			select {
			case order := <-OrderQueue:
				Log.Notice("Value is popped from channel: ", order)
				RemoveFromQueue()
			}
			enableRemove = false
		} else {
			time.Sleep(50 * time.Millisecond)
		}
	}}()
	order1 := Order{Id: "10", External: true, Floor: 4, Handler: "hello", Done: false}
	order2 := Order{Id: "20", External: false, Floor: 3, Handler: "goodbye", Done: true}
	order3 := Order{Id: "30", External: true, Floor: 2, Handler: "hei", Done: false}

	//This will add three orders on queue and channel, then the goroutine will remove the first orders on both lists
	QueueOrder(order1)
	Log.Debug("After one insert")
	for e := OrderQueueList.Front(); e != nil; e = e.Next() {
		Log.Debug(e.Value.(Order))
		//append(list, e.Value.(Order))
	}
	//time.Sleep(time.Second)
	QueueOrder(order2)
	Log.Debug("After two inserts")
	for e := OrderQueueList.Front(); e != nil; e = e.Next() {
		Log.Debug(e.Value.(Order))
		//append(list, e.Value.(Order))
	}
	//time.Sleep(time.Second)
	QueueOrder(order3)
	Log.Debug("After three inserts")
	for e := OrderQueueList.Front(); e != nil; e = e.Next() {
		Log.Debug(e.Value.(Order))
		//append(list, e.Value.(Order))
	}

	//Removing from queue is whats takes long time
	//But by waiting one millisecond it is fine
	//time.Sleep(1 * time.Millisecond)

	//get the top value of both channel and queue
	checkQueue   = OrderQueueList.Front().Value.(Order)
	Log.Error("Top value is read from queue: ", checkQueue)

	//checkChannel =  <- OrderQueue
	select {
    case x, ok := <-OrderQueue:
        if ok {
						checkChannel = x
            Log.Notice("Top value is read from channel: ", x)
        } else {
            Log.Error("Channel closed!")
        }
    default:
        Log.Error("No value ready, moving on.")
    }

	//Both list should be equal to second element
	assert.Equal(t, order2, checkChannel, "Order channel should be equal to order 2")
	assert.Equal(t, order2,checkQueue, "Order queue should be equal to order 2")
	//And they should equal each other
	assert.Equal(t, checkQueue, checkChannel, "top order should be the same on both lists")
}
