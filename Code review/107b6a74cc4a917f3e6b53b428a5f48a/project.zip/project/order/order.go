package order

import (
	"../backup"
	. "../log"
	. "../types"

	"container/list"
	"sort"
	"strconv"
	"sync"
	"time"
)

var ExternalOrders = make(chan Order)
var OrderAvailible = make(chan bool, 50)

var mutex sync.Mutex
var OrderQueue = list.New()

var mutex2 sync.Mutex
var orderNr = 0

var Free = make(chan bool, 1)

var pendingFloor = 1
var pendingOrderType = INTERNAL
var NewFloor = make(chan int)

// Register order initializes a new order, saves it
// then and queues it
func RegisterOrder(ot OrderType, floor int) {
	var handler string
	if ot == INTERNAL {
		handler = Me
	} else {
		handler = ""
	}
	order := Order{genOrderId(), ot, floor, handler, false, time.Now()}
	backup.SaveBackup(order)
	go func() {
		if order.Type == INTERNAL {
			QueueOrder(order)
		} else {
			ExternalOrders <- order
		}
	}()
}

// Queue order adds an order to the queue
// at the best position
func QueueOrder(order Order) {
	mutex.Lock()
	//OrderQueue.PushBack(order)
	insert(order)
	OrderAvailible <- true
	Log.Debug("Order added", OrderQueue.Back().Value.(Order))
	Log.Debug("Total", OrderQueue.Len())
	mutex.Unlock()
	/*
		for e := OrderQueue.Front(); e != nil; e = e.Next() {
			Log.Debug(e.Value.(Order))
		}
	*/
}

// Pop reads the next order in the queue, and removes it
func Pop() Order {
	mutex.Lock()
	var order Order
	if OrderQueue.Len() > 0 {
		order = OrderQueue.Front().Value.(Order)
		OrderQueue.Remove(OrderQueue.Front())
		Log.Debug("Popped order", order)
	} else {
		Log.Error("Queue was empty!!")
	}
	pendingFloor = order.Floor
	pendingOrderType = order.Type
	mutex.Unlock()
	return order
}

// Read reads the next order in the queue
func Read() Order {
	mutex.Lock()
	var order Order
	if OrderQueue.Len() > 0 {
		order = OrderQueue.Front().Value.(Order)
		Log.Debug("Read order", order)
	} else {
		Log.Error("Queue was empty!!")
	}
	pendingFloor = order.Floor
	pendingOrderType = order.Type
	mutex.Unlock()
	return order
}

func RestoreOrders() {
	orders := backup.FindOrders(Me)
	sort.Sort(orders)

	for _, order := range orders {
		Log.Notice("Restoring saved order", order)
		if order.Type == INTERNAL {
			// TODO set
		} else {
			// TODO set
		}
		QueueOrder(order)
	}
}

func genOrderId() string {
	for {
		select {
		case <-Free:
			orderNr++
			id := Me + "_" + strconv.Itoa(orderNr)
			Free <- true
			return id
		}
	}
}

func insert(order Order) {

	var ot OrderType
	var diff int

	// Generate a mock order that mirrors the present state of the elevator
	if State.Dir == DOWN {
		ot = GO_DOWN
		diff = -1
	} else if State.Dir == UP {
		ot = GO_UP
		diff = 1
	} else {
		ot = INTERNAL
	}
	mockOrder := Order{Floor: State.Floor + diff, Type: ot}

	first := Order{Floor: pendingFloor, Type: pendingOrderType}

	if isBetween(order, mockOrder, first) && OrderQueue.Len() > 0 {
		OrderQueue.InsertBefore(order, OrderQueue.Front())
		Log.Error("Was between")
		NewFloor <- order.Floor
		return
	}

	Log.Critical("Pending was", first)
	for e := OrderQueue.Front(); e != nil; e = e.Next() {
		next := e.Value.(Order)
		if isBetween(order, first, next) {
			// Insert it between, ie. before 'next'
			OrderQueue.InsertBefore(order, e)
			Log.Error("Was between")
			return
		}
		first = next
	}
	Log.Error("Was not between")
	// Otherwise add it to the end of the list
	OrderQueue.PushBack(order)
}

func isBetween(order Order, first Order, next Order) bool {
	if order.Floor > Max(first.Floor, next.Floor) || order.Floor < Min(first.Floor, next.Floor) {
		// it is not between
		return false
	}
	// Else the order it is between

	// Is it in the right direction?
	if first.Floor-next.Floor > 0 && (order.Type == GO_UP || first.Type == GO_UP) {
		// The first order is above the next, direction is down, and both first and order should be down or internal
		return false
	}
	if first.Floor-next.Floor < 0 && (order.Type == GO_DOWN || first.Type == GO_DOWN) {
		// The first order is below the next, direction is up, and both first and internal should be up or internal
		return false
	}
	if first.Floor == next.Floor && (order.Type != first.Type || order.Type != next.Type || order.Type != INTERNAL) {
		// The is not equal no either of them, or internal
		return false
	}
	// This returns true if order is equal to first or next. This means that we should check in main that if the previous is equal the popped order

	// If these passes, it is between and the right direction!
	return true
}

func Min(x, y int) int {
	if x < y {
		return x
	}
	return y
}

func Max(x, y int) int {
	if x > y {
		return x
	}
	return y
}
