package cost

import (
	"container/list"
	"fmt"
	"testing"
	"time"

	. "../types"
	. "./../driver"

	"github.com/stretchr/testify/assert"
)

func TestTryIt(t *testing.T) {
	assert := assert.New(t)
	assert.Equal(22*time.Second, tryIt([]int{2, 4, 3}, 2, UP, false), "They should be equal")
	assert.Equal(17*time.Second, tryIt([]int{1, 2}, 4, UP, false), "They should be equal")
	assert.Equal(22*time.Second, tryIt([]int{3, 1, 2}, 3, UP, false), "They should be equal")
	assert.Equal(22*time.Second, tryIt([]int{2, 3, 1}, 3, DOWN, false), "They should be equal")
	assert.Equal(23500*time.Millisecond, tryIt([]int{4, 2, 3}, 4, DOWN, true), "They should be equal")
	/*Door open*/
	assert.Equal(16500*time.Millisecond, tryIt([]int{4, 3}, 3, STOP, true), "They should be equal")
	/*Idle*/
	assert.Equal(0*time.Second, tryIt([]int{}, 4, STOP, false), "They should be equal")
}

func tryIt(orders []int, startFloor int, direction Direction, isDoorOpen bool) time.Duration {
	config := Configuration{2 * time.Second, 5 * time.Second}

	//theOrders := make(chan int, 10)  ---This is old (channel)
	theOrders := list.New() //---This is new (l. list)
	for _, element := range orders {
		//theOrders <- orders[index]   ---This is old (channel)
		//Example orders for testing
		var theOrder = Order{Id: "200", External: true, Floor: element, Handler: "master", Done: true} //---This is new (orders)
		theOrders.PushBack(theOrder)                                                                   //---This is new (orders)
	}
	theState := HardwareState{Floor: startFloor, Dir: direction, DoorOpen: isDoorOpen}

	theElevator := Elevator{State: theState, Config: config, Orders: theOrders}

	theDur := TimeToIdle(theElevator)
	fmt.Println("/////////////////////////")
	fmt.Println("TOTAL TIME: ", theDur)
	fmt.Println("/////////////////////////")
	return theDur
}
