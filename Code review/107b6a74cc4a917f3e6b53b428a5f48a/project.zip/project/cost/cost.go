package cost

import (
	"container/list"
	"time"

	. "../driver"
	. "../log"
	. "../order"
	. "../types"
)

type behaviour uint8

const (
	Idle behaviour = iota
	Moving
	DoorOpen
)

type Availibility struct {
	TimeToIdle time.Duration
	Timestamp  time.Time
	Floor      int
}

type Config struct {
	TravelTime   time.Duration
	DoorOpenTime time.Duration
}

type Elevator struct {
	State  HardwareState
	Config Config
	Orders *list.List
}

func (e Elevator) Action() behaviour {
	switch {
	case e.State.DoorOpen:
		return DoorOpen
	case e.State.Dir == STOP && (e.Orders.Len() == 0):
		return Idle
	default:
		return Moving
	}
}

var nextOrder Order
var Availibilities = make(map[string]Availibility)
var config = Config{TRAVEL_TIME, DOOR_OPEN_TIME}

// GetAvail estimates the time to idle for the elevator
// and returns it with a timestamp and floor
func GetAvail() Availibility {
	if !State.Responding {
		return Availibility{time.Hour, time.Now(), State.Floor}
	}
	elevatorMock := Elevator{State, config, deepCopy(OrderQueue)}
	timeToIdle := timeToIdle(elevatorMock)
	avail := Availibility{timeToIdle, time.Now(), State.Floor}
	return avail
}

// GetBest scans the recorded avabilities,
// and returns peer with the best one
func GetBest(floor int) string {
	var best = time.Hour
	var bestPeer string
	for peer, state := range Availibilities {
		t := state.TimeToIdle + time.Duration(abs(state.Floor-floor))*TRAVEL_TIME
		if t < best {
			best = t
			bestPeer = peer
		}
	}
	Log.Critical("Best at", best)
	return bestPeer
}

func UpdateAvail() {
	avail := GetAvail()
	Availibilities[Me] = avail
	Log.Debug("My avail is", avail.TimeToIdle)
}

func timeToIdle(e Elevator) time.Duration {
	var dur time.Duration
	if e.Orders.Len() != 0 {
		nextOrder = e.Orders.Front().Value.(Order)
		e.Orders.Remove(e.Orders.Front())
	}
	switch e.Action() {
	case Idle:
		return dur
	case Moving:
		e.State.Dir = chooseDirn(e)
		e.State.Floor = e.State.Floor + int(e.State.Dir)
		dur += e.Config.TravelTime / 2
	case DoorOpen:
		e.State.Dir = chooseDirn(e)
		dur += e.Config.DoorOpenTime / 2
	}

	for {
		if shouldStop(e) {
			clearRequestAtCurrentFloor(e)

			dur += e.Config.DoorOpenTime
			e.State.Dir = chooseDirn(e)
			if e.State.Dir == STOP {
				return dur
			}
		}
		dur += e.Config.TravelTime
		e.State.Floor = e.State.Floor + int(e.State.Dir)
	}
}

func shouldStop(e Elevator) bool {
	if e.State.Floor == nextOrder.Floor {
		return true
	} else {
		return false
	}
}

func chooseDirn(e Elevator) Direction {
	if e.State.Floor < nextOrder.Floor {
		return UP
	} else if e.State.Floor > nextOrder.Floor {
		return DOWN
	} else {
		return STOP
	}
}

func clearRequestAtCurrentFloor(e Elevator) {
	if e.Orders.Front() != nil {
		nextOrder = e.Orders.Front().Value.(Order) 
		e.Orders.Remove(e.Orders.Front())          
	} else {
		Log.Warning("List is empty")
	}
}

func deepCopy(original *list.List) *list.List {
	copy := list.New()
	for e := original.Front(); e != nil; e = e.Next() {
		copy.PushBack(e.Value.(Order))
	}
	return copy
}

func abs(x int) int {
	if x < 0 {
		return -x
	} else {
		return x
	}
}
