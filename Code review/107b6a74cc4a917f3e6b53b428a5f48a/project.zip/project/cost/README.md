# How the cost algorithm works

## Door Open

- When State.DoorOpen == true
- Will add DoorOpenTime/2 and go through list

## Idle

- The elevator is idle if direction is stop and length of list is 0
- If elevator is idle then it will return 0

## Moving

- Is moving if neither Door Open or Idle
- Will add TravelTime/2 and go through list

## Current floor

- Algorithm assumes current floor is set immediately after leaving a floor (e.g. if Direction is UP and Floor = 4 it assumes elevator just left Floor 3 and moves toward Floor 4)

## Direction STOP

- Algorthm assumes direction can be STOP when elevator is opening door or Idle
