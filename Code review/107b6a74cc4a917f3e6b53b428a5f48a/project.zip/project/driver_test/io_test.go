package driver_test

import (
	. "./../driver"
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestReadClearBit(t *testing.T) {
	testInit(t)

	//door := 771

	Log.Notice("Lighting door lamp in 1 sec")
	time.Sleep(1 * time.Second)
	IOSetBit(LIGHT_DOOR_OPEN)
	Log.Notice("Door lamp lit, clearing door lamp in 1 sec")
	time.Sleep(1 * time.Second)
	IO.ClearBit(LIGHT_DOOR_OPEN)
	Log.Notice("Door lamp extinguished.")
}

func testInit(t *testing.T) {
	assert.True(t, IOInit(), "Hardware FAILED to initialize")
}
