// +build linux,cgo

package driver
/*
#cgo CFLAGS: -std=c11
#cgo LDFLAGS: -lcomedi -lm
#include "io.h"
*/
import "C"

func IOInit() bool {
	return C.io_init() == 1
}

func IOSetBit(channel int) {
	C.io_set_bit(C.int(channel))
}

func IOClearBit(channel int) {
	C.io_clear_bit(C.int(channel))
}

func IOWriteAnalog(channel int, value int) {
	C.io_write_analog(C.int(channel), C.int(value))
}

func IOReadBit(channel int) bool {
	return C.io_read_bit(C.int(channel)) == 1
}

func IOReadAnalog(channel int) bool {
	return C.io_read_analog(C.int(channel)) == 1
}
