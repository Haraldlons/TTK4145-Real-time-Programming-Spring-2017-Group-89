// +build !linux

package driver

func IOInit() bool {
	return true
}

func IOSetBit(channel int) {}

func IOClearBit(channel int) {}

func IOWriteAnalog(channel int, value int) {}

func IOReadBit(channel int) bool {
	return false
}

func IOReadAnalog(channel int) int {
	return 0
}
