package driver

import (
	"fmt"
	"strconv"
	"sync"
	"testing"

	. "./../order"
	"../types"

	"github.com/stretchr/testify/assert"
)

func TestMotorAndSendors(t *testing.T) {
	ElevatorInit()
	done := GoTo(4)

	assert.True(t, done, "The car should be at floor 3")
}

func TestButtons(t *testing.T) {
	var wg sync.WaitGroup
	wg.Add(1)

	// Receivers
	go func() {
		for i := 1; i <= len(floors); i++ {
			<- OrderAvailible
			o := Pop()
			assert.Equal(t, o.Floor, i, "The first order should be to floor "+strconv.Itoa(i))
			assert.Equal(t, o.Type, types.INTERNAL, "The order should be internal")
		}
		for i := 1; i <= len(floors) - 1; i++ {
			<- OrderAvailible
			o := Pop()
			assert.Equal(t, o.Floor, i, "The first order should be to floor "+strconv.Itoa(i))
			assert.Equal(t, o.Type, types.GO_UP, "The order should be internal")
		}
		for i := 2; i <= len(floors); i++ {
			<- OrderAvailible
			o := Pop()
			assert.Equal(t, o.Floor, i, "The first order should be to floor "+strconv.Itoa(i))
			assert.Equal(t, o.Type, types.GO_DOWN, "The order should be internal")
		}
		wg.Done()
	}()

	fmt.Println("\nPush INTERNAL buttons 1 through 4, then UP buttons from floor 1 through 3, then DOWN buttons from 2 through 4")
	wg.Wait()
}
