// Package driver controlls and monitors the fysical elevator
package driver

import (
	"sync"
	"time"

	. "../log"
	"../order"
	. "../types"
)

const (
	DOOR_OPEN_TIME = 1 * time.Second
	TRAVEL_TIME    = 3 * time.Second

	INIT_INTERVAL  = 4 * time.Second
	TRAVEL_TIMEOUT = time.Duration(2) * TRAVEL_TIME //+ 1*time.Second
	CYCLE_TIMEOUT  = 7 * time.Second
)

var floors map[int]Floor
var mutex = &sync.Mutex{}
var orderedFloor int

var arrivedAt = make(chan int)

type Button struct {
	Command int
	Light   int
	Pending chan bool
}

type Floor struct {
	// The "at floor" lights are programmed in binary matching, so it is not very intuitive,
	// it is because only one light can be alight at the same time
	// some channels need to be cleared and some need to be set for each light.

	LightSet   []int
	LightClear []int

	Internal Button
	Up       Button
	Down     Button
}

func ElevatorInit() {
	for !IOInit() {
		Log.Error("The hardware did not initialize!")
		State.Responding = false
		Log.Notice("Trying agin after", INIT_INTERVAL)
		time.Sleep(INIT_INTERVAL)
	}
	State.Responding = true

	floors = make(map[int]Floor)

	//Making a mapping for every floor, with different buttons and lights
	floors[1] = Floor{
		[]int{},
		[]int{LIGHT_FLOOR_IND1, LIGHT_FLOOR_IND2},
		Button{BUTTON_COMMAND1, LIGHT_COMMAND1, make(chan bool)},
		Button{BUTTON_UP1, LIGHT_UP1, make(chan bool)},
		Button{BUTTON_DOWN1, LIGHT_DOWN1, make(chan bool)}}
	floors[2] = Floor{
		[]int{LIGHT_FLOOR_IND2},
		[]int{LIGHT_FLOOR_IND1},
		Button{BUTTON_COMMAND2, LIGHT_COMMAND2, make(chan bool)},
		Button{BUTTON_UP2, LIGHT_UP2, make(chan bool)},
		Button{BUTTON_DOWN2, LIGHT_DOWN2, make(chan bool)}}
	floors[3] = Floor{
		[]int{LIGHT_FLOOR_IND1},
		[]int{LIGHT_FLOOR_IND2},
		Button{BUTTON_COMMAND3, LIGHT_COMMAND3, make(chan bool)},
		Button{BUTTON_UP3, LIGHT_UP3, make(chan bool)},
		Button{BUTTON_DOWN3, LIGHT_DOWN3, make(chan bool)}}
	floors[4] = Floor{
		[]int{LIGHT_FLOOR_IND1, LIGHT_FLOOR_IND2},
		[]int{},
		Button{BUTTON_COMMAND4, LIGHT_COMMAND4, make(chan bool)},
		Button{BUTTON_UP4, LIGHT_UP4, make(chan bool)},
		Button{BUTTON_DOWN4, LIGHT_DOWN4, make(chan bool)}}

	for _, floor := range floors {
		IOClearBit(floor.Internal.Light)
		IOClearBit(floor.Up.Light)
		IOClearBit(floor.Down.Light)
	}

	// Assume the elevator is at, or above floor 1
	State.Floor = 2
	go watchOrders()
	go monitorOrderChanges()
	GoTo(1)
}

// GoTo will make the elevator go to the specified floor, unless it gets a contramessage via the newFloor channel
func GoTo(of int) bool {
	mutex.Lock()
	orderedFloor = of
	mutex.Unlock()
	if orderedFloor < 1 || orderedFloor > len(floors) {
		Log.Critical("Ordered floor", orderedFloor, "out of range of", len(floors), "floors")
		return false
	}
	if orderedFloor == State.Floor && State.Dir == STOP {
		Log.Notice("At correct floor already")
		return true
	}

	if orderedFloor > State.Floor {
		setDirection(UP)
	} else {
		setDirection(DOWN)
	}
	go monitorFloors()
loop:
	for {
		select {
		case floornr := <-arrivedAt:
			mutex.Lock()
			of = orderedFloor
			mutex.Unlock()
			if floornr == of {
				clearInternalOrder(floornr)
				setDirection(STOP)
				Log.Notice("At floor", floornr)
				break loop
			} else {
				go monitorFloors()
				continue
			}
		case <-time.After(TRAVEL_TIMEOUT):
			Log.Critical("Travel timeout reached!")
			State.Responding = false
			go cycleUpDown()
			return false
		}
	}
	loadCargo()
	return true
}

// SetExternalOrder will light the button accosiated with the order
func SetExternalOrder(order Order) {
	//TODO Add logic depending on the direction
	floor := floors[order.Floor]
	if order.Type == GO_UP {
		IOSetBit(floor.Up.Light)
	} else {
		IOSetBit(floor.Down.Light)
	}
}

// ClearExternalOrder will extinguish the light accossiated with the an order,
// and remove the pending status for that button
func ClearExternalOrder(order Order) {
	//TODO Add logic depending on the direction
	floor := floors[order.Floor]
	if order.Type == GO_UP {
		IOClearBit(floor.Up.Light)
		floor.Up.Pending <- false
	} else {
		IOClearBit(floor.Down.Light)
		floor.Down.Pending <- false
	}
}

func monitorOrderChanges() {
	for {
		select {
		case newFloor := <-order.NewFloor:
			mutex.Lock()
			orderedFloor = newFloor
			mutex.Unlock()
		}
	}
}

func watchOrders() {
	for i, floor := range floors {
		go func(i int, floor Floor) {
			var pending = false
			for {
				select {
				case p := <-floor.Internal.Pending:
					pending = p
				default:
				}
				if IOReadBit(floor.Internal.Command) {
					if !pending && !(State.Floor == i && State.Dir == STOP) {
						pending = true
						Log.Notice("New internal order to floor", i)
						order.RegisterOrder(INTERNAL, i)
						IOSetBit(floor.Internal.Light)
					}
				}
			}
		}(i, floor)
		go func(i int, floor Floor) {
			var pending = false
			for {
				select {
				case p := <-floor.Up.Pending:
					pending = p
				default:
				}
				if IOReadBit(floor.Up.Command) {
					if !pending && !(State.Floor == i && State.Dir == STOP) {
						pending = true
						Log.Notice("New external order up", i)
						order.RegisterOrder(GO_UP, i)
						IOSetBit(floor.Up.Light)
					}
				}
			}
		}(i, floor)
		go func(i int, floor Floor) {
			var pending = false
			for {
				select {
				case p := <-floor.Down.Pending:
					pending = p
				default:
				}
				if IOReadBit(floor.Down.Command) {
					if !pending && !(State.Floor == i && State.Dir == STOP) {
						pending = true
						Log.Notice("New external order down from floor", i)
						order.RegisterOrder(GO_DOWN, i)
						IOSetBit(floor.Down.Light)
					}
				}
			}
		}(i, floor)
	}
}

func setDirection(dir Direction) {
	if dir == STOP {
		Log.Debug("Setting motor dir stop")
		IOWriteAnalog(MOTOR, 0)
	} else if dir == UP {
		Log.Debug("Setting motor dir up")
		IOClearBit(MOTOR_DIR_DOWN)
		IOWriteAnalog(MOTOR, MOTOR_SPEED)
	} else if dir == DOWN {
		Log.Debug("Setting motor dir down")
		IOSetBit(MOTOR_DIR_DOWN)
		IOWriteAnalog(MOTOR, MOTOR_SPEED)
	}
	State.Dir = dir
}

func monitorFloors() {
	for {
		floornr := getFloor()
		if floornr != 0 && floornr != State.Floor {
			setFloor(floornr)
			arrivedAt <- floornr
			return
		}
	}
}

func getFloor() int {
	if IOReadBit(SENSOR_FLOOR1) {
		return 1
	} else if IOReadBit(SENSOR_FLOOR2) {
		return 2
	} else if IOReadBit(SENSOR_FLOOR3) {
		return 3
	} else if IOReadBit(SENSOR_FLOOR4) {
		return 4
	} else {
		return 0
	}
}

func setFloor(floornr int) {
	State.Floor = floornr
	floor := floors[floornr]

	// "At floor" lights
	go func() {
		for _, channel := range floor.LightSet {
			IOSetBit(channel)
		}
	}()
	go func() {
		for _, channel := range floor.LightClear {
			IOClearBit(channel)
		}
	}()
}

func clearInternalOrder(floornr int) {
	floor := floors[floornr]
	IOClearBit(floor.Internal.Light)
	floor.Internal.Pending <- false
}

func cycleUpDown() {
	dir := State.Dir
	go monitorFloors()
	for {
		select {
		case floornr := <-arrivedAt:
			Log.Notice("Arrived at", floornr)
			setDirection(STOP)
			State.Responding = true
			return
		case <-time.After(CYCLE_TIMEOUT):
			if dir == DOWN {
				dir = UP
			} else {
				dir = DOWN
			}
			Log.Warning("Still not arriving at any floor, setting direction", dir)
			setDirection(dir)
		}
	}
}

func loadCargo() {
	IOSetBit(LIGHT_DOOR_OPEN)
	time.Sleep(DOOR_OPEN_TIME)
	IOClearBit(LIGHT_DOOR_OPEN)
}

