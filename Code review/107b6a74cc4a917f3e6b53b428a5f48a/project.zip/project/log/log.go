package log

import (
	"os"

	"github.com/op/go-logging"
)

var Log = logging.MustGetLogger("example")

var format = logging.MustStringFormatter(
	"%{color}%{time:15:04:05.000} %{shortfunc} ▶ %{level:.4s} %{id:03x}%{color:reset} %{message}",
)

func init() {
	logLevel := ""
	var level logging.Level

	switch logLevel {
	case "debug":
		level = logging.DEBUG
	case "warn":
		level = logging.WARNING
	case "notice":
		level = logging.NOTICE
	default:
		level = logging.INFO
	}

	backend2 := logging.NewLogBackend(os.Stderr, "", 0)
	backend2Formatter := logging.NewBackendFormatter(backend2, format)

	// Only errors and more severe messages should be sent to backend1
	backend2Leveled := logging.AddModuleLevel(backend2)
	backend2Leveled.SetLevel(logging.ERROR, "")

	logging.SetBackend(backend2Leveled, backend2Formatter)

	Log.Notice(level)
}
