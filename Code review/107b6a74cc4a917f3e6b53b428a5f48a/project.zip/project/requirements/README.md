# TODO
----------------
Based on the requirements below

 - Add up and down handling

 - Test
    - Network loss

Other things (if there is time)

 - Go through the design. Maybe small structural changes
   - [BestPractices](https://talks.golang.org/2013/bestpractices.slide#1)
 - Package. Add a make file, or check how to package with 'vendor' folder
   - [StackOverflow](http://stackoverflow.com/questions/14867452/what-is-a-sensible-way-to-layout-a-go-project)
 - Clean logging, and add ablility to set level
 - Ablility to set startdirection of motor as argument
   - Or detect that the car is still, and try both directions
 - Go through code. Cleaning.

#Main requirements
-----------------
Be reasonable: There may be semantic hoops that you can jump through to create something that is "technically correct". But do not hesitate to contact us if you feel that something is ambiguous or missing from these requirements.

## No orders are lost
 - Once the light on an hall call button (buttons for calling an elevator to that floor; top 6 buttons on the control panel) is turned on, an elevator should arrive at that floor
   - [x] Implemented
   - [x] Tested

 - Similarly for a cab call (for telling the elevator what floor you want to exit at; front 4 buttons on the control panel), but only the elevator at that specific workspace should take the order
   - [x] Implemented
   - [x] Tested

 - This means handling network packet loss, losing network connection entirely, losing power - both to the elevator motor and the machine that controls the elevator, and software that crashes
   - For cab orders, handling loss of power/software crash implies that the orders are executed once service is restored
   - The time used to detect these failures should be reasonable, ie. on the order of magnitude of seconds (not minutes)

   - Power failure motor (motor stuck)
     - [x] Implemented (fails if equipment looses power, because library returns true on all channels)
     - [x] Tested

   - Network packet loss (set some random-rules in iptables)
     - [x] Implemented
     - [ ] Tested

   - Network failure (pull out network cable)
     - [x] Implemented
     - [x] Tested

   - Process freeze (kill process)
     - [x] Implemented
     - [x] Tested

 - If the elevator is disconnected from the network, it should still serve all the currently active orders (ie. whatever lights are showing)
   - [x] Implemented
   - [x] Tested

 - It should also keep taking new cab calls, so that people can exit the elevator even if it is disconnected from the network
   - [x] Implemented
   - [x] Tested

 - The elevator software should not require reinitialization (manual restart) after intermittent network or motor power loss
   - [x] Implemented
   - [x] Tested

## Multiple elevators should be more efficient than one
 - The orders should be distributed across the elevators in a reasonable way
   - Ex: If all three elevators are idle and two of them are at the bottom floor, then a new order at the top floor should be handled by the closest elevator (ie. neither of the two at the bottom).
   - [x] Implemented
   - [ ] Tested

 - You are free to choose and design your own "cost function" of some sort: Minimal movement, minimal waiting time, etc.
   - [x] Implemented
   - [x] Tested

## An individual elevator should behave sensibly and efficiently
 - No stopping at every floor "just to be safe"
   - [x] Implemented
   - [x] Tested

 - The hall "call upward" and "call downward" buttons should behave differently
   - Ex: If the elevator is moving from floor 1 up to floor 4 and there is a downward order at floor 3, then the elevator should not stop on its way upward, but should return back to floor 3 on its way down
   - [x] Implemented (this will take some energy to implement, can we use our costfunction? this also kinda contradicts with the "unspecified behevior", that we can choose to clear all orders (up or down) when arriving at a floor)
   - [x] Tested

## The lights should function as expected
 - The lights on the hall buttons should show the same thing on all `n` workspaces
   - [x] Implemented (move broadcast new order to Queue order)
   - [ ] Tested

 - The cab button lights should not be shared between elevators
   - [x] Implemented
   - [x] Tested

 - The cab and hall button lights should turn on as soon as is reasonable after the button has been pressed
   - Not ever turning on the button lights because "no guarantee is offered" is not a valid solution
   - You are allowed to expect the user to press the button again if it does not light up
   - [x] Implemented (Not set alight the button before the order is saved, and the motor is working)
   - [x] Tested

 - The cab and hall button lights should turn off when the corresponding order has been serviced
   - [x] Implemented
   - [x] Tested

 - The "door open" lamp should be used as a substitute for an actual door, and as such should not be switched on while the elevator is moving
   - The duration for keeping the door open should be in the 1-5 second range
   - [x] Implemented (1 sec)
   - [x] Tested

Start with `1 <= n <= 3` elevators, and `m == 4` floors. Try to avoid hard-coding these values: You should be able to add a fourth elevator with no extra configuration, or change the number of floors with minimal configuration. You do, however, not need to test for `n > 3` and `m != 4`.
 - [x] Implemented
 - [x] Tested
