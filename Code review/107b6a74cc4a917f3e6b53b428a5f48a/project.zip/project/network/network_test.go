package network

import (
	"encoding/json"
	"fmt"
	"strings"
	"testing"
	"time"

	"../cost"
	. "../types"
	"../watchdog"

	"github.com/stretchr/testify/assert"
)

type Tstr struct {
	A int
	B bool
}

/*
func TestReceive(t *testing.T) {
	var tstr Tstr
	var received bool

	// External receivers
	go func() {
		for {
			select {
			case msg := <-Messages:
				switch msg.ContentType {
				case "network.Tstr":
					j, _ := json.Marshal(msg.Content)
					json.Unmarshal(j, &tstr)
					fmt.Printf("Tstr received %+v\n", tstr)
				}
			case peer := <-DeadPeers:
				fmt.Println("Peer died:", peer)
			}
		}
	}()

	tst := Tstr{0, true}
	//id := "netty"

	go Listen("")
	time.Sleep(time.Second / 2)
	received = Broadcast(tst)

	assert.Equal(t, tst, tstr, "Sent struct should be same as received")
	assert.True(t, received, "We should be notified that the message is received")
}
*/
func TestReceiveOrder(t *testing.T) {
	var o Order
	var a cost.Availibility
	var received bool

	GenId()

	// External receivers
	go func() {
		for {
			select {
			case msg := <-Messages:
				switch msg.ContentType {
				case "types.Order":
					j, _ := json.Marshal(msg.Content)
					json.Unmarshal(j, &o)
					//fmt.Printf("asdfasdfasdf received %+v\n", o)
					if o.Handler == "" {
						go Broadcast(cost.GetAvail())
					}
				case "cost.Availibility":
					j, _ := json.Marshal(msg.Content)
					json.Unmarshal(j, &a)
					//fmt.Printf("asdfasdfasdf received %+v\n", a)

				}
			case peer := <-DeadPeers:
				fmt.Println("Peer died:", peer)
			}
		}
	}()

	order := MakeOrder{}
	//id := "netty"

	go Listen("")
	time.Sleep(time.Second / 2)
	time.Sleep(time.Second)
	fmt.Println(ConnectedPeers)
	if len(ConnectedPeers) == 1 {
		fmt.Println("Only myself alive, spwaning 2nd")
		watchdog.RunShellCmd("go test")
	}
	received = Broadcast(order)
	fmt.Println("Floor", order.Handler)

	time.Sleep(5 * time.Second)

	for _, peer := range ConnectedPeers {
		if peer != me {
			pid := strings.Split(peer, "-")[3]
			watchdog.Kill(pid)
		}
	}

	assert.Equal(t, order, o, "Sent struct should be same as received")
	assert.True(t, received, "We should be notified that the message is received")
}

/*
func TestPeerLost(t *testing.T) {
	time.Sleep(time.Second)
	if len(ConnectedPeers) == 1 {
		fmt.Println("Only myself alive, spwaning 2nd")
		watchdog.Run("go test")
	}
	time.Sleep(3 * time.Second)
	assert.Equal(t, len(ConnectedPeers), 2, "There should be an other peer connected")

	for _, peer := range ConnectedPeers {
		if peer != me {
			pid := strings.Split(peer, "-")[2]
			watchdog.Kill(pid)
		}
	}
	time.Sleep(3 * time.Second)
	assert.Equal(t, len(ConnectedPeers), 1, "There should only be me now")
}
*/
