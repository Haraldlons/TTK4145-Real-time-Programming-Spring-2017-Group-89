package network

import (
	"reflect"
	"strconv"
	"sync"
	"time"

	"./bcast"
	"./peers"
	. "../types"
	. "../log"
)

const (
	PEER_PORT 		= 16169
	BCAST_PORT     	= 15648

	BCAST_RETRIES  	= 15
	BCAST_INTERVAL 	= 200 * time.Millisecond

	LOST_TIMEOUT 	= 10 * time.Second
)

type Message struct {
	Id          string
	Sender      string
	Receiver    string
	Received    bool
	ContentType string
	Content     interface{} //TODO change to json.RawMessage
}

var Messages = make(chan Message)
var DeadPeers = make(chan string)
var ConnectedPeers []string

var peerTxEnable = make(chan bool)
var peerUpdateCh = make(chan peers.PeerUpdate)
var msgTx = make(chan Message)
var msgRx = make(chan Message)

var lostPeers = make(map[string]time.Time)

var pendingMsgs = make(map[string]bool)
var recordedMsgs = make(map[string]bool)
var unreceived = make(map[string]map[string]bool)

var msgNr = 0

// Listen initializes the listen for peer changes
// and messages
func Listen() {
	var peerWg sync.WaitGroup
	peerWg.Add(1)
	go peers.Receiver(15648, &peerWg, GROUP_SECRET, peerUpdateCh)
	go peers.Transmitter(15648, &peerWg, Me, peerTxEnable)

	var bcastWg sync.WaitGroup
	bcastWg.Add(1)
	go bcast.Receiver(16569, &bcastWg, msgRx)
	go bcast.Transmitter(16569, &bcastWg, msgTx)

	go readBroadcasts()
	Log.Info("Network initiated, ready to send and receive")
}

// Broadcast sends a message containing an object to all listeners
// Returns true if all connected peers respond
func Broadcast(content interface{}) bool {
	allReceived := false
	msg := Message{genMsgId(), Me, "", false, reflect.TypeOf(content).String(), content}
	unreceived[msg.Id] = sliceToMap(ConnectedPeers)
	delete(unreceived[msg.Id], Me)
	for i := 0; i < BCAST_RETRIES; i++ {
		Log.Debug("Broadcasting", msg.ContentType)
		msgTx <- msg
		time.Sleep(BCAST_INTERVAL)
		if len(unreceived[msg.Id]) == 0 {
			allReceived = true
			Log.Debug("All received", msg.ContentType)
			break
		} else {
			Log.Notice("Not yet responded:", unreceived[msg.Id])
		}
	}
	return allReceived
}

func readBroadcasts() {
	for {
		select {
		case p := <-peerUpdateCh:
			// Update connected peers
			ConnectedPeers = p.Peers

			// Record when peers are lost
			for _, peer := range p.Lost {
				lostPeers[peer] = time.Now()
			}

			// Remove peers that are back online
			delete(lostPeers, p.New)

			// Notify main if peer down for too long
			for peer, lostTime := range lostPeers {
				if time.Since(lostTime) > LOST_TIMEOUT {
					DeadPeers <- peer
				}
			}

		case msg := <-msgRx:
			if msg.Sender == Me {
				break
			}
			if msg.Receiver == "" && msg.Received == false {
				Log.Info("Got new Message", msg.ContentType, "from", msg.Sender)
				go reply(msg)
				if _, present := recordedMsgs[msg.Id]; !present {
					recordedMsgs[msg.Id] = true
					Messages <- msg
				}
			} else if msg.Receiver == Me && msg.Received == true {
				Log.Debug("Receiver received successfully", msg.ContentType)
				delete(unreceived[msg.Id], msg.Sender)
			}
		}
	}
}

func reply(msg Message) {
	msg.Received = true
	msg.Receiver = msg.Sender
	msgTx <- msg
	Log.Info("Replyed", msg.ContentType)
}

func sliceToMap(slice []string) map[string]bool {
	m := make(map[string]bool)
	for _, elem := range slice {
		m[elem] = true
	}
	return m
}

func genMsgId() string {
	msgNr++
	asdf := Me + "-" + strconv.Itoa(msgNr)
	return asdf
}
