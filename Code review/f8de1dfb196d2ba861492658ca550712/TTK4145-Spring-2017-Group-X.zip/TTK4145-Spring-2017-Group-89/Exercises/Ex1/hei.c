/* Hello World program */

#include<stdio.h>

int main(){
    printf("Hei paa deg\n");
    for(int i = 0; i<10;i++){
    	printf("Du kan lese dette tallet: %d\n",i );

    }
    printf("END");
}