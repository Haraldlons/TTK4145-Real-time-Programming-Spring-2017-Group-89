package orderservicing

import (
    "time"
    "heislab/log"
    "heislab/driver"
    . "heislab/types"
)

const DOOR_OPEN_MS = 2000

type Order struct {
    RequestID   RequestID
    Floor       Floor
    Direction   Direction
}

type State struct {
    lastDetectedFloor   Floor
    currentDirection    Direction
    doorOpen            bool
    orders              map[Floor][]Order
}

var state State = State{
    lastDetectedFloor: 0,
    currentDirection: DirectionNone,
    doorOpen: false,
    orders: make(map[Floor][]Order),
}

func MakeOrderChannels() (chan<- Order, <-chan Order, chan<- driver.ButtonLight) {
    orderCh := make(chan Order)
    orderCompletedCh := make(chan Order)
    orderPingCh := make(chan bool)
    buttonLightCh := driver.MakeButtonLightChannel()

    go func() {
        for {
            order := <-orderCh
            log.Info("Got order! %v", order)
            takeOrder(order, orderPingCh)
        }
    }()

    mainOrderServicingLoop(orderCompletedCh, orderPingCh)

    return orderCh, orderCompletedCh, buttonLightCh
}

func CalculateScore(floor Floor, direction Direction, uid UniqueID, source UniqueID) Score {
    if direction == DirectionNone {
        if source == uid {
            return Score(0)
        } else {
            return MaxScore()
        }
    }

    score := uint16(state.lastDetectedFloor.DistanceTo(floor)) << 8
    score += uint16(uid[4]) // Make score unique

    if !isFloorAhead(floor) {
        score += 0x2000
    }

    if state.currentDirection != DirectionNone && state.currentDirection != direction {
        score += 0x2000
    }

    return Score(score)
}

func mainOrderServicingLoop(
    orderCompletedCh chan<- Order,
    orderPingCh chan bool) {

    floorSensorCh := driver.MakeFloorSensorEventChannel()
    doorExtCh := driver.MakeDoorLightChannel()
    moveExtCh := driver.MakeMoveChannel()
    doorCh := make(chan bool)
    moveCh := make(chan Direction)

    go func() {
        for {
            <-orderPingCh
            orderEvent(orderCompletedCh, moveCh, doorCh)
        }
    }()

    go func() {
        for {
            select {
            case state.doorOpen = <-doorCh:
                doorExtCh <- state.doorOpen
            case state.currentDirection = <-moveCh:
                moveExtCh <- state.currentDirection
            case state.lastDetectedFloor = <-floorSensorCh:
                go func() { orderPingCh <- true }()
            }
        }
    }()
}

func takeOrder(order Order, orderPingCh chan<- bool) {
    idle := isIdle()

    state.orders[order.Floor] = append(state.orders[order.Floor], order)
    if idle {
        go func() { orderPingCh <- true }()
    }
}

func isIdle() bool {
    if state.currentDirection == DirectionNone && !state.doorOpen {
        return true
    }

    for _, orders := range state.orders {
        if len(orders) > 0 {
            return false
        }
    }

    return state.currentDirection == DirectionNone
}

func orderEvent(
    orderCompletedCh chan<- Order,
    moveCh chan<- Direction,
    doorCh chan<- bool) {


    if shouldServiceCurrentFloor() {
        log.Info("Servicing floor")
        serviceCurrentFloor(moveCh, doorCh, orderCompletedCh)
        time.Sleep(100 * time.Millisecond)
    } else {
        moveCh <- getNextDirection()
    }

}

func shouldServiceCurrentFloor() bool {
    for _, order := range state.orders[state.lastDetectedFloor] {
        if state.currentDirection == DirectionNone || order.Direction == DirectionNone || order.Direction == state.currentDirection {
            return true
        }
    }

    if state.currentDirection == DirectionNone {
        return false
    } else if isFloorExtreme(state.lastDetectedFloor) || !ordersInDirection(state.currentDirection) {
        return true
    }

    return false
}

func serviceCurrentFloor(
    moveCh chan<- Direction,
    doorCh chan<- bool,
    orderCompletedCh chan<- Order) {

    nextDirection := getNextDirection()

    lastDirection := state.currentDirection
    moveCh <- DirectionNone

    if isFloorExtreme(state.lastDetectedFloor) || nextDirection == DirectionNone {
        completeOrders(state.lastDetectedFloor, DirectionUp, orderCompletedCh)
        completeOrders(state.lastDetectedFloor, DirectionDown, orderCompletedCh)
    } else {
        completeOrders(state.lastDetectedFloor, lastDirection, orderCompletedCh)
    }


    doorCh <- true
    time.Sleep(DOOR_OPEN_MS * time.Millisecond)
    doorCh <- false

    moveCh <- nextDirection
}

func completeOrders(floor Floor, direction Direction, orderCompletedCh chan<- Order) {
    orders := state.orders[floor]
    filtered := state.orders[floor][:0]
    for i, order := range orders {
        if order.Direction == DirectionNone || order.Direction == direction {
            orderCompletedCh <- order
        } else {
            filtered = append(filtered, orders[i])
        }
    }

    if len(filtered) == 0 {
        state.orders[floor] = nil
    } else {
        state.orders[floor] = filtered
    }
}

func getNextDirection() Direction {
    curDir := state.currentDirection
    if curDir == DirectionNone {
        curDir = DirectionUp
    }

    if ordersInDirection(curDir) {
        return curDir
    } else if ordersInDirection(curDir.Opposite()) {
        return curDir.Opposite()
    }

    return DirectionNone
}

func ordersInDirection(direction Direction) bool {
    switch direction {
    case DirectionUp:
        for floor, orders := range state.orders {
            if floor > state.lastDetectedFloor && len(orders) > 0 {
                return true
            }
        }
    case DirectionDown:
        for floor, orders := range state.orders {
            if floor < state.lastDetectedFloor && len(orders) > 0 {
                return true
            }
        }
    }
    return false
}

func isFloorExtreme(floor Floor) bool {
    return floor == 0 || floor == driver.GetFloorCount() - 1
}

func isFloorAhead(floor Floor) bool {
    switch state.currentDirection {
    case DirectionUp:
        if floor == 0 {
            return false
        } else if floor == driver.GetFloorCount() - 1 {
            return true
        } else {
            return (floor - state.lastDetectedFloor) > 0
        }
    case DirectionDown:
        if floor == 0 {
            return true
        } else if floor == driver.GetFloorCount() - 1 {
            return false
        } else {
            return (floor - state.lastDetectedFloor) < 0
        }
    }
    return true
}
