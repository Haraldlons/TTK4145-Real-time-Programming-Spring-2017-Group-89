#!/bin/bash
clear

args=("$*")

echo "Running heis forever ..."
echo "heislab ${args}"

until heislab ${args}; do
    echo "Heislab crashed. Exit code $?. Restarting ..." >&2
    echo "heislab ${args}"
    sleep 1
done
