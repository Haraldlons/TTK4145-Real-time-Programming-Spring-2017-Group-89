package udp

/*
Adopted from:
https://jannewmarch.gitbooks.io/network-programming-with-go-golang-/content/socket/udp_datagrams.html
*/

import (
    "net"
    "strings"
    "hash/crc32"
    "heislab/log"
    "encoding/binary"
    "bytes"
)

var ip net.IP
var multicastAddr net.UDPAddr
var pingPort int

func Initialize(port int) {
    log.Info("Initializing UDP ...")

    fetchIPInfo(port)
}

func GetLocalIPAddress() string {
    return ip.String()
}

func GetLocalIPAddressBytes() []byte {
    ipCopy := make([]byte, 4)
    copy(ipCopy[:4], ip[12:])
    return ipCopy
}

func MakeTransmitChannel() chan<- []byte {
    transmitCh := make(chan []byte)

    go transmitToNetwork(transmitCh)

    return transmitCh;
}

func MakeReceiveChannel() <-chan []byte {
    receiveCh := make(chan []byte)

    go receiveFromNetwork(receiveCh)

    return receiveCh;
}

func transmitToNetwork(ch <-chan []byte) {
    conn, err := net.DialUDP("udp4", nil, &multicastAddr)
    log.CheckError(err)

    for {
        serializedPacket := <-ch
        serializedPacket = addCRC(serializedPacket)

        _, err = conn.Write(serializedPacket)
        log.CheckError(err)

    }

    conn.Close()
}

func receiveFromNetwork(receiveCh chan<- []byte) {
    conn, err := net.ListenMulticastUDP("udp4", nil, &multicastAddr)
    log.CheckError(err)

    for {
        var buf [512]byte
        n, _, err := conn.ReadFromUDP(buf[0:])
        log.CheckError(err)

        if !verifyCRC(buf[0:n]) {
            // CRC mismatch, discard corrupted packet
            log.Warning("CRC mismatch!")
        } else {
            // CRC was okay, so put the stripped (no CRC) buffer onto the channel
            receiveCh <- buf[0:n-4]
        }
    }

    conn.Close()
}

func fetchIPInfo(port int) {
    addrs, err := net.InterfaceAddrs()
    log.CheckError(err)

    for _, a := range addrs {
        if !strings.Contains(a.String(), ":") && !strings.HasPrefix(a.String(), "127.") {
            ip, _, _ = net.ParseCIDR(a.String())
            break
        }
    }

    multicastAddr = net.UDPAddr{net.ParseIP("224.0.0.1"), port, ""}
}

func verifyCRC(serializedPacket []byte) bool {
    n := len(serializedPacket)
    crcReceived := serializedPacket[n-4:]
    crc := calculateCRC(serializedPacket[:n-4])

    return bytes.Equal(crcReceived, crc)
}

func addCRC(serializedPacket []byte) []byte {
    crc := calculateCRC(serializedPacket)
    return append(serializedPacket[:], crc[:]...)
}

func calculateCRC (serializedPacket []byte) []byte {
    crc := crc32.ChecksumIEEE(serializedPacket)
    crcAsBytes := make([]byte, 4)
    binary.BigEndian.PutUint32(crcAsBytes, uint32(crc))

    return crcAsBytes
}
