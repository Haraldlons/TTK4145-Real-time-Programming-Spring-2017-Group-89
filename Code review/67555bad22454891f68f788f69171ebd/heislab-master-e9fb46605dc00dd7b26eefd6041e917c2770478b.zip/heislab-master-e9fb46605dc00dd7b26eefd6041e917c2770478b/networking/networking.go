package networking

import (
    "time"
    "bytes"
    "encoding/binary"
    "heislab/log"
    . "heislab/types"
    "heislab/networking/udp"
)

const PING_TIME_MS = 500
const PING_TIMEOUT_MS = PING_TIME_MS * 4

type Packet []byte

var uniqueID UniqueID
var requestReceiveCh chan Request
var requestTransmitCh chan Request

var remoteElevators map[UniqueID]time.Time


func Initialize(id byte, port int) {
    log.Info("Initializing networking ...")
    udp.Initialize(port)
    ip := udp.GetLocalIPAddressBytes()
    copy(uniqueID[:4], ip[:4])
    uniqueID[4] = id

    remoteElevators = make(map[UniqueID]time.Time)

    makeTransmitListener()
    makeReceiveListener()

    log.Info("Unique ID: %v", uniqueID)
}

func GetUniqueID() [5]byte {
    return uniqueID
}

func MakeRequestReceiveChannel() <-chan Request {
    publicRqReceiveCh := make(chan Request)
    go func() {
        for {
            publicRqReceiveCh <- <-requestReceiveCh
        }
    }()
    return publicRqReceiveCh
}

func MakeRequestTransmitChannel() chan<- Request {
    publicRqTransmitCh := make(chan Request)
    go func() {
        for {
            requestTransmitCh <- <-publicRqTransmitCh
        }
    }()
    return publicRqTransmitCh
}

func GetPingableElevators() []UniqueID {
    var pingList []UniqueID
    for uid, _ := range remoteElevators {
        pingList = append(pingList, uid)
    }

    return pingList
}

func makeTransmitListener() {
    udpTransmitCh := udp.MakeTransmitChannel()
    requestTransmitCh = make(chan Request)
    pingTransmitCh := makeLocalPingTransmitter()
    go func() {
        for {
            select {
            case request := <-requestTransmitCh:
                udpTransmitCh <- serialize(request)
            case ping := <-pingTransmitCh:
                udpTransmitCh <- ping[:]
            }
        }
    }()
}

func makeReceiveListener() {
    udpReceiveCh := udp.MakeReceiveChannel()
    requestReceiveCh = make(chan Request)
    pingReceiveCh := makeRemotePingListener()
    go func() {
        for {
            received := <-udpReceiveCh
            if len(received) == 5 {
                // It's a ping
                var recvID UniqueID
                copy(recvID[:], received[:])
                if recvID != uniqueID {
                    pingReceiveCh <- recvID
                }
            } else {
                // It's a packet
                request := deserialize(received)
                if request.Sender != uniqueID {
                    requestReceiveCh <- request
                }
            }
        }
    }()
}

func makeRemotePingListener() chan<- UniqueID {
    pingCh := make(chan UniqueID)

    go func() {
        for {
            uid := <-pingCh
            now := time.Now()
            if _, ok := remoteElevators[uid]; !ok {
                log.Info("Elevator %v discovered!", uid)
            }
            remoteElevators[uid] = now
        }
    }()

    return pingCh
}

func makeLocalPingTransmitter() <-chan UniqueID {
    pingTransmitCh := make(chan UniqueID)

    go func() {
        for range time.Tick(PING_TIME_MS * time.Millisecond) {
            pingTransmitCh <- uniqueID

            now := time.Now()
            for uid, time := range remoteElevators {
                if now.Sub(time).Seconds() * 1000 > PING_TIMEOUT_MS {
                    delete(remoteElevators, uid)
                    log.Warning("Elevator %v timed out!", uid)
                }
            }
        }
    }()

    return pingTransmitCh
}

func serialize(request Request) Packet {
    buf := &bytes.Buffer{}
    err := binary.Write(buf, binary.BigEndian, &request)
    log.CheckError(err)

    return buf.Bytes()
}

func deserialize(packet Packet) Request {
    request := Request{}

    buf := bytes.NewReader(packet)
    err := binary.Read(buf, binary.BigEndian, &request)
    log.CheckError(err)

    return request
}
