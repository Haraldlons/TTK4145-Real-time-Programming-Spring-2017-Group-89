package driver

/*
#cgo CFLAGS: -std=gnu99
#cgo LDFLAGS: -lcomedi -lm -lpthread
#include "elev.h"
*/
import "C"
import (
    "time"
    "heislab/log"
    . "heislab/types"
)

var floorCount uint

type Button struct {
    Direction Direction
    Floor Floor
}

type ButtonLight struct {
    Button Button
    Enabled bool
}

func Initialize(simulator, dryRun bool, _floorCount uint) {
    log.Info("Initalizing driver ...")
    floorCount = _floorCount

    if dryRun {
        return
    }
    if simulator {
        err := C.elev_init(C.ET_Simulation)
        if(err != 0) {
            log.Error(true, "Error connecting to elevator simulator!")
        }
    } else {
        err := C.elev_init(C.ET_Comedi)
        if(err != 0) {
            log.Error(true, "Error connecting to elevator hardware!")
        }
    }

    moveToKnownState()
}

func MakeMoveChannel() chan<- Direction {
    moveCh := make(chan Direction)

    go func() {
        for {
            direction := <-moveCh
            move(direction)
        }
    }()

    return moveCh
}

func MakeDoorLightChannel() chan<- bool {
    doorLightCh := make(chan bool)

    go func() {
        for {
            enabled := <-doorLightCh
            setDoorLight(enabled)
        }
    }()

    return doorLightCh
}

func MakeButtonLightChannel() chan<- ButtonLight {
    buttonLightCh := make(chan ButtonLight)

    go func() {
        for {
            buttonLight := <-buttonLightCh
            setButtonLight(buttonLight)
        }
    }()

    return buttonLightCh
}

func MakeButtonEventChannel() <-chan Button {
    buttonCh := make(chan Button)
    var buttonStates = make([][3]bool, floorCount)

    go func() {
        pollTicker := time.NewTicker(10 * time.Millisecond)

        for range pollTicker.C {
            for floor, btns := range buttonStates {
                for dir, _ := range btns {
                    btn := getButtonPressed(Direction(dir), Floor(floor))
                    if buttonStates[floor][dir] != btn && buttonStates[floor][dir]{
                        button := Button{Direction(dir), Floor(floor)}
                        log.Info("Elevator button pressed: %v", button)
                        buttonCh <- button
                    }
                    buttonStates[floor][dir] = btn
                }
            }
        }
    }()

    return buttonCh
}

func MakeFloorSensorEventChannel() <-chan Floor {
    sensorCh := make(chan Floor)
    floor := NoFloor

    go func() {
        pollTicker := time.NewTicker(10 * time.Millisecond)

        for range pollTicker.C {
            currentFloor := getFloorSensor()
            if currentFloor != floor {
                floor = currentFloor
                if floor != NoFloor {
                    log.Info("Elevator passed floor: %v", floor)
                    setFloorIndicator(floor)
                    sensorCh <- floor
                }
            }
        }
    }()

    return sensorCh
}

func GracefulShutdown() {
    moveToKnownState()
    log.Error(true, "Shutting down")
}

func GetFloorCount() Floor {
    return Floor(floorCount)
}

func moveToKnownState() {
    floor := getFloorSensor()
    move(DirectionDown)
    for floor == -1 {
        floor = getFloorSensor()
        time.Sleep(100 * time.Millisecond)
    }
    move(DirectionNone)
}

func move(direction Direction) {
    switch direction {
    case DirectionUp:
        C.elev_set_motor_direction(1)

    case DirectionDown:
        C.elev_set_motor_direction(-1)

    case DirectionNone:
        C.elev_set_motor_direction(0)
    }
}

func getFloorSensor() Floor {
    return Floor(C.elev_get_floor_sensor_signal())
}

func setFloorIndicator(floor Floor) {
    C.elev_set_floor_indicator(C.int(floor))
}

func getButtonPressed(direction Direction, floor Floor) bool {
    var button C.int

    switch direction {
    case DirectionUp:
        button = C.elev_get_button_signal(0, C.int(floor))

    case DirectionDown:
        button = C.elev_get_button_signal(1, C.int(floor))

    case DirectionNone:
        button = C.elev_get_button_signal(2, C.int(floor))
    }

    return button != 0
}

func setDoorLight(enable bool) {
    C.elev_set_door_open_lamp(C.int(boolToInt(enable)))
}

func setButtonLight(buttonLight ButtonLight) {
    var floor = C.int(buttonLight.Button.Floor)
    var enable = C.int(boolToInt(buttonLight.Enabled))

    switch buttonLight.Button.Direction {
    case DirectionUp:
        C.elev_set_button_lamp(0, floor, enable)

    case DirectionDown:
        C.elev_set_button_lamp(1, floor, enable)

    case DirectionNone:
        C.elev_set_button_lamp(2, floor, enable)
    }
}

func boolToInt(value bool) int {
    if value {
        return 1
    } else {
        return 0
    }
}
