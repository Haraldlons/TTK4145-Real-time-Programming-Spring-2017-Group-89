package main

import (
    "flag"
    "time"
    "runtime"
    "heislab/log"
    "heislab/driver"
    "heislab/request"
    "heislab/networking"
)

const PORT = 12003

func main() {
    runtime.GOMAXPROCS(10)

    simulator := flag.Bool("s", false, "Run with simulator")
    dryRun := flag.Bool("d", false, "Enable dry-run")
    id := flag.Uint("i", 256, "Elevator id")
    floorCount := flag.Uint("f", 4, "Floor count")
    flag.Parse()

    if *id > 255 {
        log.Error(true, "ID must be in the range 0 to 255!")
    }

    if *dryRun {
        log.Warning("Dry run enabled!")
    }

    driver.Initialize(*simulator, *dryRun, *floorCount)
    networking.Initialize(byte(*id), PORT)
    request.Initialize()


    for {
        time.Sleep(100 * time.Millisecond)
    }
}
