package request

import (
    "time"
    "crypto/md5"
    "encoding/binary"
    "heislab/log"
    "heislab/driver"
    . "heislab/types"
    "heislab/networking"
    "heislab/orderservicing"
)

const REQUEST_TIMEOUT = 30

type DelegationType int8
const (
    Undelegated     DelegationType = iota
    DelegatedLocal  DelegationType = iota
    DelegatedRemote DelegationType = iota
)

type RequestData struct {
    requestID       RequestID
    owner           UniqueID
    floor           Floor
    direction       Direction
    scores          map[UniqueID]Score
    delegation      DelegationType
}

func Initialize() {
    log.Info("Initalizing request ...")
    makeRequestListener()
}

func makeRequestListener() {
    rqNewCh := make(chan Request)
    rqScoreCh := make(chan Request)
    rqCompletedCh := make(chan RequestID)

    buttonCh := driver.MakeButtonEventChannel()
    netRequestCh := networking.MakeRequestReceiveChannel()
    orderCh, orderCompletedCh, buttonLightCh := orderservicing.MakeOrderChannels()

    go func() {
        for {
            select {
            case button := <-buttonCh:
                rqNewCh <- requestFromButton(button)
            case request := <-netRequestCh:
                if request.Type == RequestCompleted {
                    rqCompletedCh <- request.RequestID
                } else {
                    rqScoreCh <- request
                }
            case order := <-orderCompletedCh:
                rqCompletedCh <- order.RequestID
            }
        }
    }()

    makeRequestMaintainer(rqNewCh, rqScoreCh, rqCompletedCh, orderCh, buttonLightCh)
}

func makeRequestMaintainer(
    rqNewCh <-chan Request,
    rqScoreCh chan Request,
    rqCompletedCh <-chan RequestID,
    orderCh chan<- orderservicing.Order,
    buttonLightCh chan<- driver.ButtonLight) {

    timeoutCh := make(chan RequestID)
    rqBroadcastCh := networking.MakeRequestTransmitChannel()
    knownRequests := make(map[RequestID]RequestData)

    go func() {
        for {
            select {
            case rq := <-rqNewCh:
                handleRequestNew(rq, knownRequests, rqScoreCh)
            case rq := <-rqScoreCh:
                handleRequestScore(rq, knownRequests, rqBroadcastCh, timeoutCh, buttonLightCh)
            case rqid := <-rqCompletedCh:
                handleRequestCompleted(rqid, knownRequests, rqBroadcastCh, buttonLightCh)
            case rqid := <-timeoutCh:
                handleTimeout(rqid, knownRequests, rqScoreCh, rqBroadcastCh)
            case <-time.After(100 * time.Millisecond):
                maintainKnownRequests(knownRequests, orderCh)
            }
        }
    }()
}

func handleRequestNew(
    rq Request,
    knownRequests map[RequestID]RequestData,
    rqScoreCh chan<- Request) {

    if isSimilarRequestKnown(knownRequests, rq) {
        return
    }

    go func() { rqScoreCh <- rq }()
}

func handleRequestScore(
    rq Request,
    knownRequests map[RequestID]RequestData,
    rqBroadcastCh chan<- Request,
    timeoutCh chan<- RequestID,
    buttonLightCh chan<- driver.ButtonLight) {

    if !isRequestKnown(knownRequests, rq.RequestID) {
        log.Info("New request! %v", rq.RequestID)
        knownRequests[rq.RequestID] = getRequestData(rq)
        go func() {
            time.Sleep(REQUEST_TIMEOUT * time.Second)
            timeoutCh <- rq.RequestID
        }()
    }

    if knownRequests[rq.RequestID].delegation != Undelegated {
        return
    }

    // Save received score
    knownRequests[rq.RequestID].scores[rq.Sender] = rq.Score

    if rq.Type != RequestAllScoresKnown {
        // Broadcast own score
        rqBroadcastCh <- getRequest(knownRequests[rq.RequestID])
    }

    if rq.Direction != DirectionNone || (rq.Direction == DirectionNone && rq.Owner == networking.GetUniqueID()) {
        buttonLightCh <- driver.ButtonLight{driver.Button{rq.Direction, rq.Floor}, true}
    }
}

func handleRequestCompleted(
    rqid RequestID,
    knownRequests map[RequestID]RequestData,
    rqBroadcastCh chan<- Request,
    buttonLightCh chan<- driver.ButtonLight) {

    rq := getRequest(knownRequests[rqid])
    if rq.Direction != DirectionNone || (rq.Direction == DirectionNone && rq.Owner == networking.GetUniqueID()) {
        buttonLightCh <- driver.ButtonLight{driver.Button{rq.Direction, rq.Floor}, false}
    }

    if knownRequests[rqid].delegation == DelegatedLocal {
        // Request originates from me
        rq.Type = RequestCompleted
        rqBroadcastCh <- rq
    }
    delete(knownRequests, rqid)
    log.Info("Request completed! %v", rqid)
}

func handleTimeout(
    rqid RequestID,
    knownRequests map[RequestID]RequestData,
    rqScoreCh chan<- Request,
    rqBroadcastCh chan<- Request) {

    if !isRequestKnown(knownRequests, rqid) {
        return
    }

    switch knownRequests[rqid].delegation {
    case DelegatedLocal:
        rqBroadcastCh <- getRequest(knownRequests[rqid])
        log.Error(false, "Local request timeout %v, trying to shut down gracefully", rqid)
        time.Sleep(1000 * time.Millisecond)
        gracefulShutdown()
    case DelegatedRemote:
        log.Warning("Remote request timeout %v", rqid)
        rebroadcastRequest(knownRequests, rqBroadcastCh, rqid)
    case Undelegated:
        log.Warning("Undelegated request timeout %v", rqid)
        rebroadcastRequest(knownRequests, rqBroadcastCh, rqid)
    }
}

func rebroadcastRequest(knownRequests map[RequestID]RequestData, rqBroadcastCh chan<- Request, rqid RequestID) {
    rqData := knownRequests[rqid]
    delete(knownRequests, rqid)
    go func() {
        rqBroadcastCh <- getRequest(rqData)
    }()
}

func gracefulShutdown() {
    go func() {
        time.Sleep(10 * time.Second)
        log.Error(true, "Unable to shut down gracefully!")
    }()
    driver.GracefulShutdown()
}

func maintainKnownRequests(knownRequests map[RequestID]RequestData, takeOrderCh chan<- orderservicing.Order) {
    for rqid, rqData := range knownRequests {
        if rqData.delegation == Undelegated && areAllScoresKnown(rqData.scores) {
            if isMyScoreBest(rqData.scores) {
                log.Info("All scores known; my score is best! %v", rqid)
                rqData.delegation = DelegatedLocal
                takeOrderCh <- makeOrder(knownRequests[rqid])
            } else {
                log.Info("All scores known; my score is not best! %v", rqid)
                rqData.delegation = DelegatedRemote
            }
            knownRequests[rqid] = rqData
        }
    }
}

func isRequestKnown(knownRequests map[RequestID]RequestData, rqid RequestID) bool {
    _, exists := knownRequests[rqid]
    return exists
}

func isSimilarRequestKnown(knownRequests map[RequestID]RequestData, rq Request) bool {
    for _, rqData := range knownRequests {
        if rqData.direction == rq.Direction && rqData.floor == rq.Floor {
            if rq.Direction == DirectionNone {
                return rqData.owner == rq.Owner
            } else {
                return true
            }
        }
    }
    return false
}

func areAllScoresKnown(rqScores map[UniqueID]Score) bool {
    for _, uid := range networking.GetPingableElevators() {
        if _, ok := rqScores[uid]; !ok {
            return false
        }
    }
    return true
}

func isMyScoreBest(rqScores map[UniqueID]Score) bool {
    lowest := networking.GetUniqueID()
    for uid, score := range rqScores {
        if score < rqScores[lowest] {
            lowest = uid
        }
    }
    return lowest == networking.GetUniqueID() && rqScores[lowest] != MaxScore()
}

func getRequestData(rq Request) RequestData {
    rqData := RequestData {
        requestID: rq.RequestID,
        owner: rq.Owner,
        scores: make(map[UniqueID]Score),
        floor: rq.Floor,
        direction: rq.Direction,
        delegation: Undelegated,
    }
    rqData.scores = map[UniqueID]Score{
        networking.GetUniqueID(): orderservicing.CalculateScore(rqData.floor, rqData.direction, networking.GetUniqueID(), rqData.owner),
    }
    return rqData
}

func getRequest(rqData RequestData) Request {
    request := Request {
        RequestID: rqData.requestID,
        Owner: rqData.owner,
        Sender: networking.GetUniqueID(),
        Type: RequestScore,
        Score: orderservicing.CalculateScore(rqData.floor, rqData.direction, networking.GetUniqueID(), rqData.owner),
        Floor: rqData.floor,
        Direction: rqData.direction,
    }

    if areAllScoresKnown(rqData.scores) {
        request.Type = RequestAllScoresKnown
    }

    return request
}

func requestFromButton(button driver.Button) Request {
    uid := networking.GetUniqueID()
    timestamp := time.Now().UnixNano()
    md5Checksum := getRequestChecksum(uid, timestamp)
    score := orderservicing.CalculateScore(button.Floor, button.Direction, uid, uid)


    request := Request {
        RequestID: md5Checksum,
        Owner: networking.GetUniqueID(),
        Sender: networking.GetUniqueID(),
        Type: RequestScore,
        Score: score,
        Floor: button.Floor,
        Direction: button.Direction,
    }

    return request
}

func getRequestChecksum(uid [5]byte, timestamp int64) [16]byte {
    timeAsByte := make([]byte, 8)
    binary.LittleEndian.PutUint64(timeAsByte, uint64(timestamp))
    uidAndTimestamp := append(uid[:], timeAsByte[:]...)

    return md5.Sum(uidAndTimestamp)
}

func makeOrder(rqData RequestData) orderservicing.Order {
    return orderservicing.Order {
        RequestID: rqData.requestID,
        Floor: rqData.floor,
        Direction: rqData.direction,
    }
}
