package types

import (
    "fmt"
    "math"
)

type UniqueID [5]byte
type Floor int16

const (
    NoFloor         Floor = -1
)

type Direction int8

const (
    DirectionUp     Direction = iota
    DirectionDown   Direction = iota
    DirectionNone   Direction = iota
)

type RequestType int8
const (
    RequestScore            RequestType = iota
    RequestAllScoresKnown   RequestType = iota
    RequestCompleted        RequestType = iota
)

type Score uint16
type RequestID [16]byte

type Request struct {
    // requestId will be a MD5 of timestamp, salted by elevator IP. Used to have unique orders
    RequestID       RequestID
    Owner           UniqueID
    Sender          UniqueID
    Type            RequestType
    Score           Score
    Floor           Floor
    Direction       Direction
}

func (rqid RequestID) String() string {
    return fmt.Sprintf("%x", rqid[:])
}

func (uid UniqueID) String() string {
    return fmt.Sprintf("%v@%v.%v.%v.%v", uid[4], uid[0], uid[1], uid[2], uid[3])
}

func (from Floor) DistanceTo(to Floor) int {
    // Simply return magnitude of distance
    return int(math.Abs(float64(from - to)))
}

func (dir Direction) Opposite() Direction {
    if dir == DirectionUp {
        return DirectionDown
    } else if dir == DirectionDown {
        return DirectionUp
    }

    return DirectionNone
}

func MaxScore() Score {
    return ^Score(0)
}
